var express = require('express');
var router = express.Router();


var workshops=[{"latitude":"22.497107","longitude":"88.515900","Address":"Bantala leather complex","ShopName":"Abc Cars Ltd"},
     {"latitude":"23.497107","longitude":"81.515900","Address":"Bantala ABC complex","ShopName":"SAW Cars Ltd"},
     {"latitude":"20.497107","longitude":"82.515900","Address":"XTY complex","ShopName":"PQR Cars Ltd"},
     {"latitude":"12.497107","longitude":"80.515900","Address":"KOLKATA AXZ complex","ShopName":"XYZ Cars Ltd"}];

     router.get('/',(req,res,next)=>{
        res.status(200).json(workshops);
     });

     module.exports=router;
