var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var mongooseStringQuery =require('mongoose-string-query');

var  PolicySchema = new Schema(
	{
		policyid: {
			type: String,
			lowercase: true,
			trim: true,
			index: true,
			unique: true,
			required: true
		},
		vehicleno: {
			type: String,
			lowercase: true,
			trim: true,
			index: true,
			unique: true,
			required: true
		},
		make: {
			type: String,
			required: true			
		},
		policyholderName: {
			type: String,
			trim: true,
			required: true
		},
		model: {
			type: String,
			trim: true,
			default: ''
		},
		year: {
			type: String,
			trim: true,
			default: ''
		},
		color: {
			type: String,
			trim: true,
			default: ''
		}		
	},
	{ collection: 'Policy'}
);

PolicySchema.plugin(mongooseStringQuery);
module.exports = exports = mongoose.model('Policy', PolicySchema);
