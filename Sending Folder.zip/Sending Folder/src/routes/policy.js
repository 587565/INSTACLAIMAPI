//var Policy =require('../controllers/policy');
/*
module.exports = api => {
	api.route('/policies').get(Policy.list);
	api.route('/policies/:policyid').get(Policy.get);
	//api.route('/users/:userId').put(User.put);
	//api.route('/users/').post(User.post);
	//api.route('/users/:userId').delete(User.delete);
};
*/
var express = require('express');
var router = express.Router();
var Course=require('../models/course');
var mongoose = require('mongoose');


var courses=[{"name":"BTech","Fees":20000},
			{"name":"BCom","Fees":5000},
			{"name":"BPharma","Fees":3000}]

router.get('/',(req,res,next)=>{
	Course.find()
	.select('name fees')
	.exec()
	.then(docs=>{
		const response={
			count:docs.length,
			courses:docs
		}; 
		res.status(200).json({
			message:'Working Route--Get All!!!',
			resp: response
		}); 

	});
	

});

router.get('/:name',(req,res,next)=>{

	var course=courses.find(x=>x.name==req.params.name)
	res.status(200).json({
		message:'Working Route--Get One!!!',
		FindCourse:course
	})

});
//Post Request 
router.post('/',(req,res,next)=>{
	var course=new Course({
		//_id: new mongoose.Types.objectId(), 
		name:req.body.name,
		fees:req.body.fees
		});
		console.log("Name"+req.body.name);
		console.log("Fees"+req.body.fees);
		course.save().then(result => {
		console.log(result)})
		.catch(err=>console.log(err));
		res.status(201).json({
		message:'Working Route--Post One!!!',
		PostedCourse:course
	})

});

module.exports=router;
