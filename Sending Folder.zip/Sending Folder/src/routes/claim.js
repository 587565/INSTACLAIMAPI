var express = require('express');
var router = express.Router();
var Claim=require('../models/claim');
var mongoose = require('mongoose');

router.get('/',(req,res,next)=>{
	Claim.find()
	.select()
	.exec()
	.then(docs=>{
        /*
		const response={
			count:docs.length,
			claims:docs
		}; 
		res.status(200).json({
			message:'Working Route--Get All Claims!!!',
			resp: response
        }); */
        res.status(200).json(docs);

    });
});

    //GET claim by claimid
    router.get('/:claimid',(req,res,next)=>{

        var claim={}
        Claim.find()
        .select()
        .exec()
        .then(docs=>{
            const response={
                count:docs.length,
                claims:docs
            };  

            claim=response.claims.find(x=>x.claimid==req.params.claimid);
            /*
            res.status(200).json({
               // message:'Working Route--Get One!!!',
               // FindClaim:claim
               claim
            }); */
            res.status(200).json(claim);
        });
    });

    router.post('/',(req,res,next)=>{
        var newClaims=new Claim(
            {   
                _id:new mongoose.Types.ObjectId(),
                leftimg:req.body.leftimg,
                rightimg:req.body.rightimg,
                frontimg:req.body.frontimg,
                backimg:req.body.backimg,
                policyid:req.body.policyid,
                claimid: req.body.claimid,
                model:req.body.model,
                lossdate:req.body.lossdate,
                losscause:req.body.losscause,
                sublosscause:req.body.sublosscause,
                peopleinjured:req.body.peopleinjured
            });
            newClaims.save().then(result => {
                console.log(result)})
                .catch(err=>console.log(err));
                res.status(201).json({
                message:'Data Saved Successfully !!!',
                PostedClaim:newClaims
            });

    });

	module.exports=router;

