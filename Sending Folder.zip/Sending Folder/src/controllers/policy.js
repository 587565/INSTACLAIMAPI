var async =require('async');
var Policy= require('../models/policy');
var logger = require('../utils/logger');

exports.list = (req, res) => {
	const params = req.params || {};
	const query = req.query || {};

	const page = parseInt(query.page, 10) || 0;
	const perPage = parseInt(query.per_page, 10) || 10;

	Policy.apiQuery(req.query)
		.select('policyid vehicleno make model year color')
		.then(policies => {
			res.json(policies);
		})
		.catch(err => {
			res.status(422).send(err.errors);
		});
};

exports.get = (req, res) => {
	Policy.findById(req.params.policyid)
		.then(policy => {
			res.json(policy);			
		})
		.catch(err => {			
			res.status(422).send(err.errors);
		});
};

exports.post = (req, res) => {
	const data = Object.assign({}, req.body, { user: req.policy.sub }) || {};
	Policy.create(data)
		.then(policy => {
			res.json(policy);
		})
		.catch(err => {
			//logger.error(err);
			res.status(500).send(err);
		});
};

// exports.delete = (req, res) => {
// 	User.findByIdAndUpdate(
// 		{ _id: req.params.user },
// 		{ active: false },
// 		{
// 			new: true
// 		}
// 	)
// 		.then(user => {
// 			if (!user) {
// 				return res.sendStatus(404);
// 			}

// 			res.sendStatus(204);
// 		})
// 		.catch(err => {
// 			logger.error(err);
// 			res.status(422).send(err.errors);
// 		});
// };
