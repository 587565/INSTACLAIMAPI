
var express = require('express');
const app = express();
const morgan=require('morgan');
const bodyParser=require('body-parser');
const db = require('./utils/db');


/*
app.use((req,res,next)=>{

    res.status(200).json({message:"Working Boss!!!"});
});
*/


var router = express.Router();
const policyRoutes=require('./routes/policy');
const claimRoutes=require('./routes/claim');
const workshopRoutes=require('./routes/workshop')

app.use(morgan('dev'));
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());


db.once('open', function() {
	console.log("DB connection alive");
  }); 


app.use('/policy',policyRoutes);
app.use('/claim',claimRoutes);
app.use('/workshop',workshopRoutes);

app.use((req,res,next)=>{
	let error= new Error('Not found');
	error.status(404);
	next(error);
});

app.use((error,req,res,next)=>{
	res.status(error.status||500);
	res.json({
		error:{message:error.message}
	});
});




module.exports = app;

/*
app.listen(port,err=>{
	if (err) {
		logger.error(err);
		process.exit(1);
	}
	fs.readdirSync(path.join(__dirname, 'routes')).map(file => {
		require('./routes/' + file)(api);
	});
});
console.log('Magic happens on port ' + port);
module.exports = api;
*/
