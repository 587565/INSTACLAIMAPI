const http=require('http');
const app=require('./app');

var port = process.env.PORT || 8082; // set our port


const server=http.createServer(app);

console.log('Server is working on port ' + port);
server.listen(port)
