var mongoose = require('mongoose');

const claimSchema=mongoose.Schema({
    _id:mongoose.Schema.Types.ObjectId,
    leftimg:String,
    rightimg:String,
    frontimg:String,
    backimg:String,
    policyid:String,
    claimid: String,
    model:String,
    lossdate:Date,
    losscause:String,
    sublosscause:String,
    peopleinjured:Number
});
module.exports=mongoose.model('Claim',claimSchema);